import java.io.IOException;


public class EditableBufferedReader {

    public EditableBufferedReader(){

    }

    public static void setRaw(){
        String [] rw = {"/bin/sh", "-c", "stty raw </dev/tty"};
        try{
            Runtime.getRuntime().exec(rw);
        }catch(IOException ioe){
            System.out.println(ioe);
        }
    }
    public static void unsetRaw(){
        String [] rw = {"/bin/sh", "-c", "stty cooked </dev/tty"};
        try{
            Runtime.getRuntime().exec(rw);
        }catch(IOException ioe){
            System.out.println(ioe);
        }
    }
    public static void read(){

    }
    public static void readLine(){

    }

    public static void main(String[] args) {
        EditableBufferedReader.unsetRaw();
    }
}
