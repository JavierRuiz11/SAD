public class Main {

    public static void main(String[] args) {
        EditableBufferedReader ebr = new EditableBufferedReader();
        ebr.setRaw();
    }
}