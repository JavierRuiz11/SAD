
public class Prueba {


    String lin;
   public Prueba(){

    lin = "abcdef";


   }

   
  public String delete(int cursor){

    if(cursor>1){

        lin = lin.substring(0, cursor-1) + lin.substring(cursor);

    }

    return lin;
}

   public static void main(String[] args) {
    
   Prueba p = new Prueba();
      

      
         System.out.println(p.delete(2));
              


   
    

   }
    
}
