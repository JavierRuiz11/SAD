import com.sun.jna.Library;
import com.sun.jna.Structure;
import com.sun.jna.Native;
import java.io.IOException;
import java.util.Arrays;
import java.lang.String;


public class Main {
    public static void main(String[] args) throws IOException {

        /*System.out.println("\033[4;31;44mHello world!\033[0mHello");
        System.out.println("[4mDEMBELE");
        System.out.println("[2JH"); //borra la pantalla

        while(true){

            int key = System.in.read();
            System.out.println((char) key +" ("+key+")");


        }


         */

        LibC.Termios termios = new LibC.Termios();
        int rc = LibC.INSTANCE.tcgetattr(LibC.SYSTEM_OUT_FD, termios);


        if (rc != 0) {

            System.err.println("ERROR!!!");
            System.exit(rc);


        }
        System.out.println("termios: " + termios);
    }
}

        interface LibC extends Library{

            int SYSTEM_OUT_FD = 0;
            int ISIG = 1, ICANON = 2, ECHO = 10, TCSAFLUSH = 2, IXON = 2000, ICRNL = 400, IEXTEN = 100000, OPOST = 1, VMIN = 6, VTIME = 6, TIOCGWINSZ = 0x5413;

            // loading C Sstandard library for POSIX systems
            LibC INSTANCE = Native.load("c", LibC.class);


            @Structure.FieldOrder(value = {"c_iflag", "c_oflag", "c_cflag", "c_lflag", "c_cc"})

            class Termios extends Structure {

                public int c_iflag;      /* input modes */
                public int c_oflag;      /* output modes */
                public int c_cflag;      /* control modes */
                public int c_lflag;      /* local modes */
                public byte c_cc[] = new byte[19];   /* special characters */

                public Termios(){}

                public static Termios of(Termios t){

                    Termios copy = new Termios();
                    copy.c_iflag = t.c_iflag;
                    copy.c_oflag = t.c_oflag;
                    copy.c_cflag = t.c_cflag;
                    copy.c_lflag = t.c_lflag;
                    copy.c_cc = t.c_cc.clone();

                     return  copy;


                }

                public String toString() {

                    return "Termios{" +"c_iflag=" +  c_iflag +
                            "c_oflag=" + c_oflag +
                            "c_cflag=" + c_cflag +
                            "c_lflag=" + c_lflag +
                            "c_cc=" + Arrays.toString(c_cc) + "}\n";


                }

            }


        int tcgetattr(int fd, Termios term);
        int tcsetattr(int fd, int optional_actions, Termios term);




    }
