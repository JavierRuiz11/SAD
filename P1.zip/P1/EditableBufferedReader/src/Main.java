import com.sun.jna.Structure;
import com.sun.jna.Library;
import com.sun.jna.Native;
import java.lang.String;



public class Main {

    public static void main(String[] args) {

        Lib.Termios termios = new Lib.Termios();
        int rc = Lib.INSTANCE.tcgetattr(Lib.SYSTEM_OUT_FD, termios);

        if (rc != 0) {
            System.err.println("problema con tcget");
            System.exit(rc);
        }

        System.out.println("termios = " + termios);
    }

    interface Lib extends Library {
        int SYSTEM_OUT_FD = 0;
        int ISIG = 1, ICANON = 2, ECHO = 10, TCSAFLUSH = 2, IXON = 2000, ICRNL = 400, IEXTEN = 100000, OPOST = 1, VMIN = 6, VTIME = 5, TIOCGWINSZ = 0x5413;
        Lib INSTANCE = Native.load("c", Lib.class);

        @Structure.FieldOrder(value = {"c_iflag", "c_oflag", "c_cflag", "c_lflag", "c_cc"})
        class Termios extends Structure {

            public int c_iflag;
            public int c_oflag;
            public int c_cflag;
            public int c_lflag;
            public byte[] c_cc = new byte[19];

            public Termios() {

            }

            public static Termios of(Termios t) {
                Termios copy = new Termios();
                copy.c_iflag = t.c_iflag;
                copy.c_oflag = t.c_oflag;
                copy.c_cflag = t.c_cflag;
                copy.c_lflag = t.c_lflag;
                copy.c_cc = t.c_cc.clone();
                return copy;
            }

        }

        int tcgetattr(int fd, Termios termios);

        int tcsetattr(int fd, int optional_actions, Termios termios);

    }
}