import javax.sound.sampled.Line;
import java.io.*;


public class EditableBufferedReader extends BufferedReader {


    public static final int ARROW_RIGHT = 1000;
    public static final int ARROW_LEFT = 1001;
    public static final int HOME = 1002;
    public static final int END = 1003;
    public static final int INS = 1004;
    public static final int DEL = 1005;

    public static final int ENTER =13;
    public static final int ESC = 27;
    public static final int BACKSPACE = 127;
    public static int tecla;
    public Line line;




    public EditableBufferedReader(Reader in, int sz) {
        super(in, sz);
    }


    public void setRaw() {
        String[] rw = {"/bin/sh", "-c", "stty raw </dev/tty"};
        try {
            Runtime.getRuntime().exec(rw);
        } catch (IOException ioe) {
            System.out.println(ioe);
        }
    }

    public void unsetRaw() {
        String[] rw = {"/bin/sh", "-c", "stty cooked </dev/tty"};
        try {
            Runtime.getRuntime().exec(rw);
        } catch (IOException ioe) {
            System.out.println(ioe);
        }
    }

    public int read() throws IOException { //leer caracter y clasificar teclas raras

        setRaw();

        int key = super.read();

        if(key != '\033'){

            tecla = key;
            return tecla;

        }
        int key2 = super.read();
        if(key != '['){

           tecla = ESC;
           return tecla;

        }
        int key3= super.read();
        switch(key3) {

            case 'C':
                tecla = ARROW_RIGHT;
                return tecla;

            case 'D':
                tecla = ARROW_LEFT;
                return tecla;

            case 'F':
                tecla = END;
                return tecla;

            case 'H':
                tecla = HOME;
                return tecla;

        }
            if(key3 =='3' || key3 =='4' || key3 == '7' || key3 == '8') {
                int key4 = super.read();
                if (key4 == '~') {

                    switch (key3) {

                        case '3':
                            tecla = DEL;
                            return tecla;

                        case '4':
                            tecla = END;
                            return tecla;

                        case '8':
                            tecla = END;
                            return tecla;

                        case '7':
                            tecla = HOME;
                            return tecla;


                    }

                }
            }

        unsetRaw();
        return tecla;

    }
    //public static String readLine() {     //leer una linea hasta el enter y busvar caracter raro y luego hacer funcion de clase line con un switch(left, up,...)


    //}


    public static void main(String[] args) throws IOException {

        Reader r = new InputStreamReader(System.in);
        EditableBufferedReader buf= new EditableBufferedReader(r, 1000);
        int t = buf.read();
        System.out.println((char)t + "("+t+")");

    }
}
