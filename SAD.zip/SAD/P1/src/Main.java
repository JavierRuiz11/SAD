public class Main {

    public static void main(String[] args) {
        EditableBufferedReader ebr = new EditableBufferedReader();
        ebr.setRaw();


        int key = System.in.read();
        if(key!='\033'){

            tecla = key;
            return key;

        }
        int nextKey = System.in.read();
        if(nextKey != '[' && nextKey !='0'){

            tecla = ESC;
            return nextKey;

        }

        int anotherKey = System.in.read();

        if(nextKey == '['){

            return switch(anotherKey){


                case 'C' -> tecla = ARROW_RIGHT;
                case 'D' -> tecla = ARROW_LEFT;
                case 'H' -> tecla = HOME;
                case 'F' -> tecla = END;
                case '0', '1','2','3','4','5', '6', '7', '8', '9' ->{

                    int yetAnotherkey = System.in.read();
                    if(yetAnotherkey !='~')  {                          //altgr+4

                        yield  yetAnotherkey;

                    }

                    switch (anotherKey){

                        case '3' : yield  tecla = DEL;
                        case '4', '8' : yield tecla = END;
                        case '7': yield tecla = HOME;
                        default: yield anotherKey;



                    }

                }
                default -> anotherKey;

            };

        }
    }
}