import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.util.Scanner;




public class EditableBufferedReader {

    public EditableBufferedReader() {

    }

    public static void setRaw() {
        String[] rw = {"/bin/sh", "-c", "stty raw </dev/tty"};
        try {
            Runtime.getRuntime().exec(rw);
        } catch (IOException ioe) {
            System.out.println(ioe);
        }
    }

    public static void unsetRaw() {
        String[] rw = {"/bin/sh", "-c", "stty cooked </dev/tty"};
        try {
            Runtime.getRuntime().exec(rw);
        } catch (IOException ioe) {
            System.out.println(ioe);
        }
    }

    public static void read() throws IOException {
        Scanner keyboard = new Scanner(System.in);
        char c= 0;
        int i =0;
        char salto = '\n';
        char car[];
        car = new char[100];
        while(c!=salto){

            c = keyboard.next().charAt(i);
            car[i]=c;

            i++;
        }
        System.out.println(c);




    }
    public static void readLine() {
        Scanner teclado = new Scanner(System.in);
        String s = new String();
        s = teclado.nextLine();
        System.out.println(s);
    }


    public static void main(String[] args) throws IOException {
        EditableBufferedReader.read();
    }
}
